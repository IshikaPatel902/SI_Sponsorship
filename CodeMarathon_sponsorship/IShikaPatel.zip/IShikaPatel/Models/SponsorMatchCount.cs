﻿namespace CodeMarathon_sponsorship.Models
{
    public class SponsorMatchCount
    {
        public int SponsorId { get; set; }
        public string SponsorName { get; set; }
        public int NumberOfMatches { get; set; }
    }
}
