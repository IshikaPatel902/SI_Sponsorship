const Banner = () => {
    return <div className="banner">Welcome to the Sponsorship App</div>;
  };
  
  export default Banner;
  