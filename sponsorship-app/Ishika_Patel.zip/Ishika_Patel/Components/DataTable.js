import React from 'react';
import './DataTable.css';  // Import the CSS file for styling

const DataTable = ({ data }) => {
  return (
    <div className="table-container">
      <table className="styled-table">
        <thead>
          <tr>
            <th>Sponsor ID</th>
            <th>Sponsor Name</th>
            <th>Total Payment</th>
            <th>Number of Payments</th>
            <th>Latest Payment Date</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.sponsorId}>
              <td>{item.sponsorId}</td>
              <td>{item.sponsorName}</td>
              <td>${item.totalPayment.toLocaleString()}</td>
              <td>{item.numberOfPayments}</td>
              <td>{item.LatestPaymentDate}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DataTable;
