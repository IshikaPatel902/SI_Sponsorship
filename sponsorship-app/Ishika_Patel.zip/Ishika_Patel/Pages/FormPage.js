import React from 'react';
import Form from '../Components/Form';
import NavBar from '../Components/NavBar';

const FormPage = () => {
  return (
    <div>
      <NavBar />
      <h2>Submit Sponsor Data</h2>
      <Form />
    </div>
  );
};

export default FormPage;
