import axios from 'axios';

const API_BASE_URL = 'http://localhost:5167/api/Payment/sponsor-sum';

export const fetchSponsors = async () => {
  return axios.get(API_BASE_URL);
};

export const submitSponsor = async (data) => {
  return axios.post(API_BASE_URL, data);
};

const apiService = axios.create({
  baseURL: 'http://localhost:5167',
  headers: {
    'Content-Type': 'application/json',
  },
});

export default apiService;
