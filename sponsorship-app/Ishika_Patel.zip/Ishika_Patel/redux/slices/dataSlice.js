

import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  sponsors: [
    { 
      sponsorId: 1, 
      sponsorName: 'Nike', 
      totalPayment: 225000, 
      numberOfPayments: 3, 
      LatestPaymentDate: '2024-09-10' 
    },
    { 
      sponsorId: 2, 
      sponsorName: 'Adidas', 
      totalPayment: 200000, 
      numberOfPayments: 2, 
      LatestPaymentDate: '2024-07-20' 
    },
    { 
      sponsorId: 3, 
      sponsorName: 'Red Bull', 
      totalPayment: 1119997, 
      numberOfPayments: 5, 
      LatestPaymentDate: '2024-11-11' 
    },
    { 
      sponsorId: 4, 
      sponsorName: 'Puma', 
      totalPayment: 180000, 
      numberOfPayments: 2, 
      LatestPaymentDate: '2024-08-10' 
    },
    { 
      sponsorId: 5, 
      sponsorName: 'Under Armour', 
      totalPayment: 134008, 
      numberOfPayments: 2, 
      LatestPaymentDate: '2024-12-12' 
    },
    { 
      sponsorId: 6, 
      sponsorName: 'Coca Cola', 
      totalPayment: 119008, 
      numberOfPayments: 2, 
      LatestPaymentDate: '2024-02-20' 
    },
    { 
      sponsorId: 7, 
      sponsorName: 'Pepsi', 
      totalPayment: 87500, 
      numberOfPayments: 1, 
      LatestPaymentDate: '2024-08-01' 
    },
    { 
      sponsorId: 8, 
      sponsorName: 'Samsung', 
      totalPayment: 150000, 
      numberOfPayments: 1, 
      LatestPaymentDate: '2024-12-10' 
    },
    { 
      sponsorId: 9, 
      sponsorName: 'Sony', 
      totalPayment: 135000, 
      numberOfPayments: 1, 
      LatestPaymentDate: '2024-05-25' 
    },
    { 
      sponsorId: 10, 
      sponsorName: 'Visa', 
      totalPayment: 160000, 
      numberOfPayments: 2, 
      LatestPaymentDate: '2024-05-10' 
    }
  ],
  status: 'idle',
  error: null,
};

const dataSlice = createSlice({
  name: 'data',
  initialState,
  reducers: {
   
  },
});

export const selectSponsors = (state) => state.data.sponsors;
export const selectStatus = (state) => state.data.status;
export const selectError = (state) => state.data.error;

export default dataSlice.reducer;
